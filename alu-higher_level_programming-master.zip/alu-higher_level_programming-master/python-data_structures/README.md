data structure in python
