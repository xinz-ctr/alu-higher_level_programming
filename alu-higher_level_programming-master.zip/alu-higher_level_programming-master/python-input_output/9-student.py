#!/usr/bin/python3
"""Module that defines a Student class with JSON serialization support."""


class Student:
    """A class that defines a student by first name, last name and age."""

    def __init__(self, first_name, last_name, age):
        """Initialize a Student with first_name, last_name and age."""
        self.first_name = first_name
        self.last_name = last_name
        self.age = age

    def to_json(self):
        """Return the dictionary representation of the Student instance."""
        return self.__dict__
