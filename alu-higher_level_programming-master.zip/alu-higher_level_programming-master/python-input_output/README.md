Python - Input/Output
