#!/usr/bin/python3
"""Module that defines Square inheriting from Rectangle."""
Rectangle = __import__("9-rectangle").Rectangle


class Square(Rectangle):
    """A square class that inherits from Rectangle."""

    def __init__(self, size):
        """Initialize Square with validated size."""
        self.integer_validator("size", size)
        super().__init__(size, size)
        self.__size = size
