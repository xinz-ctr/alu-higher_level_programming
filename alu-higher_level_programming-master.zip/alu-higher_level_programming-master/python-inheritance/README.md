Python - Inheritance
