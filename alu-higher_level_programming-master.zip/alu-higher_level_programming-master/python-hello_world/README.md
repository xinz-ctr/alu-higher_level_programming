python basics
