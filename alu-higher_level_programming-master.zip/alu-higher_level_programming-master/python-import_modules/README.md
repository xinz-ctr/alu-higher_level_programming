functions in python projects
